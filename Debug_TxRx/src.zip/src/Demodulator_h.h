/*
 * Demodulator_h.h
 *
 *  Created on: 13 Apr 2018
 *      Author: JULIAN MORTIMER
 */

#ifndef DEMODULATOR_H_H_
#define DEMODULATOR_H_H_

typedef struct sHwModulator HwModulator;
struct sHwModulator {
    u32 dummy;
};

typedef struct sHwDemodulator HwDemodulator;
struct sHwDemodulator {
    u32 dummy;
};


#endif /* DEMODULATOR_H_H_ */
