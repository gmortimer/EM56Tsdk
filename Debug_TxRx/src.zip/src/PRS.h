#ifndef PRS_H_
#define PRS_H_

extern u32 PRS_2048[];
extern u32 PRS_1024[];
extern u32 PRS_512[];
extern u32 PRS_256[];
extern u32 PRS_128[];
extern u32 PRS_64[];

extern u32 *PRS_gens[];

#endif // PRS_H_
