#ifndef __XPLATFORM_CONFIG_H_
#define __XPLATFORM_CONFIG_H_

#define STDOUT_IS_PS7_UART
#define UART_DEVICE_ID 0
#endif
