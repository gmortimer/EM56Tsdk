/*
 * cplx32.h
 *
 *  Created on: 16 Aug 2018
 *      Author: JULIAN MORTIMER
 */

#ifndef CPLX32_H_
#define CPLX32_H_

typedef struct sCplx32 Cplx32;
struct sCplx32 {
    s16 real;
    s16 imag;
};

#endif /* CPLX32_H_ */
